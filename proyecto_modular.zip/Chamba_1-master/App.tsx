
// Importacion para el el drawer navigation

import 'react-native-gesture-handler';
// Importacion de los componentes para utilizar la navegación
import AppContainer from './src/components/app-container';
import Navigator from './src/';
import { AuthProvider } from './src/context/AuthContext';
import { RegistersProvider } from './src/context/RegistersContext';

const AppState = ({ children }: { children: JSX.Element | JSX.Element[] }) => {
  return (
    <AuthProvider>
      <RegistersProvider>
        { children }
      </RegistersProvider>
    </AuthProvider>

  )
}

export const App = () => {
  return (
  <AppContainer>
    <AppState>
     <Navigator/>
    </AppState>
  </AppContainer>
  )
}

