// Importaciones base
import React, { useContext } from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import 'react-native-gesture-handler';

// Importaciones de los compoenntes a renderizar
import { AuthContext } from './context/AuthContext';
import RegisterScreen from './screens/RegisterScreen';
import LoginScreen from './screens/LoginScreen';
import { LoadingScreen } from './screens/LoadingScreen';
import { RegisterNavigator } from './navigator/RegisterNavigator';

// Objeto para generar un sidebar de deslizamiento
const Stack = createStackNavigator();

const App = () => {

    const {status} = useContext(AuthContext);

    if(status === 'checking') return <LoadingScreen/>

    return (
        <Stack.Navigator 
            initialRouteName="Login" 
            screenOptions={{ headerShown:false }}
            //drawerContent={props => <SideBar {...props} />}    
        >
            {
                status !== 'authenticated'
                ? (
                    <>
                      <Stack.Screen name="Register" component={RegisterScreen} />
                      <Stack.Screen name="Login" component={LoginScreen} />
                    </>
                )
                : (
                    <Stack.Screen name="Main" component={RegisterNavigator} />

                )
            }
            {/* Lista de rutas para el redireccionamiento */}           

        </Stack.Navigator>
    );
}
export default App;