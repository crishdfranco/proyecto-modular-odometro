import { Usuario } from "../interfaces/appInterfaces";

/*Estados de autenticacion*/
export interface AuthState {
    status: 'checking' | 'authenticated' | 'not-authenticated';
    token: string | null;
    errorMessage: string;
    user: Usuario | null;    
}

/*Datos que se recibiran de la base de datos*/
type AuthAction = 
     | { type: 'signUp', payload: {token: string, user: Usuario} }
     | { type: 'addError', payload: string }
     | { type: 'removeError' }
     | { type: 'notAuthenticated' }
     | { type: 'logout' }

export const authReducer = ( state: AuthState, action: AuthAction ): AuthState => {
    switch (action.type) {
        case 'addError':
            return {
                /*Validar si el usuario no esta autenticado*/
                ...state,
                user: null,
                status: 'not-authenticated',
                token: null,
                errorMessage: action.payload
            }

            case 'removeError':
                return {
                    ...state,
                    errorMessage: ''
                };
    
            case 'signUp':
                return {
                    /*Verificar token, asignando el estado de autenticado, 
                    agregar el token y el usuario del usuario logeado */
                    ...state,
                    errorMessage: '',
                    status: 'authenticated',
                    token: action.payload.token,
                    user: action.payload.user
                }

            /*Cambiar a usuario no autenticado y borrar el token y el usuario*/        
            case 'logout':
            case 'notAuthenticated':
                return {
                    ...state,
                    status: 'not-authenticated',
                    token: null,
                    user: null
                }
    }
}

