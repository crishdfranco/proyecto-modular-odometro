import React, { createContext, useEffect, useState } from 'react'
import {  Registro, nRueda, manageRegisterResponse} from '../interfaces/appInterfaces';
import cycloApi from '../api/cycloApi';


type RegistersContextProps = {
    register : string;
    getRegisters: ()=> Promise<void>;
    saveRegister: (nRueda : string)=> Promise<void>;
    updateRegister: (nRueda : string)=> Promise<void>;
}

export const RegisterContext = createContext({} as RegistersContextProps);

export const RegistersProvider = ({children}: any)=>{
    
    const [register, setRegister] = useState<string>("");

    const getRegisters = async()=>{

        try{
            const resp = await cycloApi.get<manageRegisterResponse>('/registros/');
    
            if(resp.status == 204){
                setRegister("");
                return;
            }
            
            const register : string = resp.data.registro;
            setRegister(register);

        }catch(error){
            
        }
    }

    const saveRegister = async(nRueda : string)=>{
        const resp = await cycloApi.post<manageRegisterResponse>('/registros/guardarRegistro',{nRueda});
        const register : string = resp.data.registro
        setRegister(register)

    }

    const updateRegister = async(nRueda : string)=>{
        const resp = await cycloApi.put<manageRegisterResponse>('/registros/', {nRueda});
        console.log(resp.data);
        const register : string = resp.data.registro
        setRegister(register)
    }
    
    return(
        <RegisterContext.Provider value={{
            register,
            getRegisters,
            saveRegister,
            updateRegister        
        }}>
            {children}
        </RegisterContext.Provider>
    )
}