import React, { createContext, useEffect, useReducer } from "react";
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Usuario, LoginResponse, LoginData, RegisterData } from '../interfaces/appInterfaces';
import { authReducer, AuthState } from "./AuthReducer";
import cycloApi from "../api/cycloApi";

/*Objetos para realizar la autenticación */
type AuthContextProps = {
    errorMessage: string;
    token: string | null;
    user: Usuario | null;
    status: 'checking' | 'authenticated' | 'not-authenticated';
    signUp: (registerData: RegisterData) => void;
    signIn: (loginData: LoginData) => void;
    logOut: () => void;
    removeError: () => void;

}

/*Se establece el estado inicial de la aplicacion*/
const authInicialState: AuthState = {
    status: 'checking',
    token: null,
    user: null,
    errorMessage: ''
}

export const AuthContext = createContext({} as AuthContextProps);

export const AuthProvider = ({ children }: any) => {

    const [ state, dispatch ] = useReducer( authReducer, authInicialState);

    useEffect(() => {
      checkToken();
    }, [])

    /*Se revisa si el usuario esta autenticado o no revisando si hay un token*/
    const checkToken = async() => {
        const token = await AsyncStorage.getItem('token')
        //No hay token, no autenticado
        if( !token ) return dispatch({ type:'notAuthenticated' });

        //Si hay token
        const resp = await cycloApi.get('/auth');
        if (resp.status !== 200) {
            return dispatch({ type:'notAuthenticated'});
        }
        
        await AsyncStorage.setItem('token', resp.data.token);

        dispatch({
            type: 'signUp',
            payload: {
                token: resp.data.token,
                user: resp.data.usuario
            }
        });
    }

    
    /*Solicitud de inicio de sesion*/
    const signIn =async ({correo, password}: LoginData) => {
        try {

            const {data} = await cycloApi.post<LoginResponse>('/auth/login', {correo, password});
            dispatch({
                type: 'signUp',
                /*Se obtienen el token y los datos del usuario recividos de la solicitud*/
                payload: {
                    token: data.token,
                    user: data.usuario
                }
            });

            /*Se almacena de manera local el token del usuario ingresado*/
            await AsyncStorage.setItem('token', data.token);
            
        } catch (error: any) {
            dispatch({
                type: 'addError', 
                payload: error.response.data.msg || 'Revise la información' 
            })            
        }
        
    };
    
    /*Solicitud de registro de una nueva cuenta */
    const signUp = async({nombre, correo, password}: RegisterData) => {
        try {

            const {data} = await cycloApi.post<LoginResponse>('/usuarios', {nombre, correo, password});
            dispatch({
                type: 'signUp',
                /*Se obtienen el token y los datos del usuario recividos de la solicitud*/
                payload: {
                    token: data.token,
                    user: data.usuario
                }
            });

            /*Se almacena de manera local el token del usuario ingresado*/
            await AsyncStorage.setItem('token', data.token);
            
        } catch (error: any) {
            dispatch({
                type: 'addError', 
                payload: error.response.data.errors[0].msg || 'Algo salió mal, revise los datos'
            })            
        }
    };

    /*Función para cerrar sesión*/    
    const logOut = async() => {
        await AsyncStorage.removeItem('token'); //El token almacenado es eliminado
        dispatch({type: 'logout'}); //Se actualiza el estado de la aplicacion
    };

    const removeError = () => {
        dispatch({ type : 'removeError'});
    };

        return(
        <AuthContext.Provider value={{
            ...state,
            signUp,
            signIn,
            logOut,
            removeError,

        }}>
            { children }
        </AuthContext.Provider>
    )
}