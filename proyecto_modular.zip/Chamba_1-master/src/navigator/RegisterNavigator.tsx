import { createStackNavigator } from '@react-navigation/stack'
import React, {useContext, useEffect, useState} from 'react'

import FirstSettingsScreen from '../screens/FirstSettingsScreen'
import MainScreen from '../screens/MainScreen'
import { RegisterContext } from '../context/RegistersContext'
import { LoadingScreen } from '../screens/LoadingScreen'


export type RegisterStackParams = {
    FirstSettingsScreen : undefined,
    MainScreen : undefined 
}

const Stack = createStackNavigator<RegisterStackParams>();

export const RegisterNavigator = () => {

  const {register,getRegisters} = useContext(RegisterContext);
  const [loading, setloading] = useState(true);
 // Lógica para determinar si ya hay registros
 const hasRegisters = register.length > 0;

 const handleGetRegister = async ()=>{
    await getRegisters();
    setloading(false);
    
 }

 useEffect(() => {
   // Realiza las acciones que necesitas cuando el componente se monta
   handleGetRegister();
 }, [loading]);

 console.log(loading);
//  Pantalla de carga para cambiar de vista
  if (loading) return <LoadingScreen/>;

 return (
   <Stack.Navigator screenOptions={{ headerShown: false }}>
     {/* Condicional para mostrar FirstSettingsScreen solo si no hay registros */}
     {hasRegisters ? (
       <Stack.Screen name="MainScreen" component={MainScreen} />
     ) : (
       <Stack.Screen name="FirstSettingsScreen" component={FirstSettingsScreen} />
     )}
   </Stack.Navigator>
 );
}
