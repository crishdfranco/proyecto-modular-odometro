//Importacion de componentes
import {useWindowDimensions} from 'react-native';
//Importar componentes de native base
import { Image } from 'native-base';

/*Componente para el logo del login y el register*/
export default function LoginScreen() {

  const {width} = useWindowDimensions();

  return (
      /*imagen con el logo*/
      <Image
        source={require('../assets/Logo.png')}
        position="absolute"
        w={width * 1.1}
        top={-8}
        right={0}
        left={-20}
        bottom={0}
        zIndex={-10}
        resizeMode="contain"
        alt="logo"
      />
  );
}
