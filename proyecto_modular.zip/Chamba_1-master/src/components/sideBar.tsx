// Importaciones base
import React , {useCallback} from 'react';
import {
    HStack,
    VStack,
    Center,
    Avatar,
    Heading,
    IconButton,
    useColorModeValue
} from 'native-base';
import MenuButton from './menu-button';
import { DrawerContentComponentProps } from '@react-navigation/drawer';

 const sideBar = (props: DrawerContentComponentProps) => {

    const {state, navigation } = props;
    const currentRoute = state.routeNames[state.index];

    const handlePressMenuMain = useCallback(()=>{
        navigation.navigate('Main');
    },[navigation]);

    const handlePressMenuLogin = useCallback(()=>{
        navigation.navigate('Login');
    },[navigation]);

    const handlePressMenuRegister = useCallback(()=>{
        navigation.navigate('Register');
    },[navigation]);

  return (
    <MenuButton
        active = {currentRoute === "Main"}
        onPress={ handlePressMenuMain}
        icon='box'
    >
        Inicio
    </MenuButton>
  )
}

export  default sideBar;
