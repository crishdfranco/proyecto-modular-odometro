// Importaciones base
import React from 'react';
import {Button, IButtonProps}  from 'native-base';

// Interfaz para los parámetros para el componente del botón
interface Props extends IButtonProps {
    active : boolean;
    icon : string;
    children : React.ReactNode;
}

// Componente para los botones para el sidebar
const MenuButton = ({active, icon, children, ...props} : Props) => {
    const colorScheme = 'blue'
    const inactiveTextColor = 'blue.500'
    const pressedBgColor = 'primary.100'
    // const colorIcon = 'muted.400'

    return (
        <Button
            size="lg"
            colorScheme={colorScheme}
            bg={active ? undefined : 'transparent'}
            _pressed={{
                bg : pressedBgColor
            }}
            _text={{
                color : active ? 'blue.50' : inactiveTextColor
            }}
            variant="solid"
            justifyContent="flex-start"
            {...props}

        >
            {children}
        </Button>
    )
}

export default MenuButton;