import React, {useContext, useEffect, useState} from 'react';
import { Alert } from 'react-native';
// Importacion para generar gráficas
import {BarChart} from 'react-native-gifted-charts';
import {AuthContext} from '../context/AuthContext';
import {
  VStack,
  Center,
  HStack,
  Heading,
  Box,
  Text,
  Image,
  Button,
  ScrollView,
  Pressable,
  HamburgerIcon,
  Select,
  CheckIcon,
  Menu,
  Modal
} from 'native-base';
import {RegisterContext} from '../context/RegistersContext';
import {useForm} from '../hooks/useForm';


export default function MainScreen() {

  // Información de prueba para la gráfica
  const barData = [
    {value: 18, label: 'L'},
    {value: 30, label: 'M', frontColor: '#E43B3B'},
    {value: 24, label: 'M'},
    {value: 15, label: 'J'},
    {value: 22, label: 'V'},
    {value: 12, label: 'S'},
    {value: 15, label: 'D'},
  ];

  // 
  const {user, logOut} = useContext(AuthContext);
  const {register, updateRegister} = useContext(RegisterContext);
  const {numeroRodado, onChange, clearForm} = useForm({
    numeroRodado: '',
  });
  const [showModal, setShowModal] = useState(false);


  const hadleUpdateRodado = ()=>{
    if (numeroRodado.length == 0) return;
      updateRegister(numeroRodado);
      clearForm();
      setShowModal(false);
      Alert.alert('Éxito', 'Se ha actualizado el rodado de la bicicleta',[{
        text: 'Cerrar',
      }]
      );
  }
  


  return (
    <ScrollView>
      <VStack flex={1} bg="gray.100" px="7">
        {/* Menu hamburguesa */}
        <VStack left="-155px" mt="5">
          <Box w="100%" alignItems="center">
            <Menu
              w="250"
              px="2"
              trigger={triggerProps => {
                return (
                  <Pressable
                    accessibilityLabel="More options menu"
                    {...triggerProps}>
                    <HamburgerIcon size="3xl" />
                  </Pressable>
                );
              }}>
                <Menu.Group title="Cuenta" >
                  <Menu.Item py="3" _text={{ fontSize: 'lg'}}>{user?.nombre || ''}</Menu.Item>
                  <Menu.Item onPress={logOut} py="3" _text={{ fontSize: 'lg'}}>Cerrar sesión</Menu.Item>
                </Menu.Group>
            </Menu>
          </Box>
        </VStack>
        {/* Hero */}
        <VStack h="300px" mt={4} w="full">
          <Image
            source={require('../assets/bicicleta.png')}
            position="absolute"
            top={0}
            right={-59}
            bottom={0}
            zIndex={-10}
            w="250px"
            resizeMode="contain"
            alt="bicicleta"
          />
          <Heading>¡ Bienvenido de vuelta</Heading>
          <Heading >{user?.nombre} !</Heading>

          
          {/* Información del recorrido en kilómetros en tiempo real, por el momento es información estática */}
          <VStack w="full" mt={5}>
            <Text fontSize="2xl" pl={2} fontWeight="bold" color="muted.500">
              Distancia
            </Text>
            <HStack w="full" space={2} alignItems="flex-end" mt={-3}>
              <Heading fontSize="95px">16,2</Heading>
              <Box height="45px">
                <Text fontSize="2xl" color="muted.500" fontWeight="bold">
                  km
                </Text>
              </Box>
            </HStack>
          </VStack>
        </VStack>
        {/* Fin Hero */}

        {/* Información de la velocidad máxima llegada, elevación, Cambiar el rodado*/}
        <VStack space={5} mt={10}>
          <HStack w="full" alignItems="flex-start">
            <Center w="50%">
              <Heading color="muted.600">Elevación</Heading>
              <Text fontWeight="bold" fontSize="5xl">
                700
              </Text>
              <Text>msnm</Text>
            </Center>
            <Center w="50%">
              <Heading color="muted.600">Velocidad</Heading>
              <Text fontWeight="bold" fontSize="5xl">
                15
              </Text>
              <Text>km/h</Text>
            </Center>
          </HStack>

          {/* Modal para cambiar rodado */}
          <HStack w="full" alignItems="flex-start">
            <Center w="50%">
              <Heading color="muted.600">
                Rodado: {register ? register : 'No especificado'}
              </Heading>
              <Center mt="10px">
                <Button
                  bg="gray.900"
                  p={0}
                  px={3}
                  py={2}
                  onPress={() => setShowModal(true)}>
                  Cambiar rodado
                </Button>
                <Modal isOpen={showModal} onClose={() => setShowModal(false)}>
                  <Modal.Content maxWidth="400px">
                    <Modal.CloseButton />
                    <Modal.Header>Actualizar tamaño de rueda</Modal.Header>
                    <Modal.Body>
                      <Select
                        selectedValue={numeroRodado}
                        minWidth="200"
                        accessibilityLabel="Elegir el rodado de tu bicicleta"
                        placeholder="Elegir el rodado de tu bicicleta"
                        _selectedItem={{
                          bg: 'teal.600',
                          endIcon: <CheckIcon size="5" />,
                        }}
                        mt={1}
                        onValueChange={itemValue =>
                          onChange(itemValue, 'numeroRodado')
                        }>
                        <Select.Item label="26'" value="26" />
                        <Select.Item label="27.5'" value="27.5" />
                        <Select.Item label="29" value="29" />
                      </Select>
                    </Modal.Body>
                    <Modal.Footer>
                      <Button.Group space={2}>
                        <Button
                          variant="ghost"
                          colorScheme="blueGray"
                          onPress={() => {
                            setShowModal(false);
                          }}>
                          Cancelar
                        </Button>
                        <Button bg="gray.900" onPress={() => hadleUpdateRodado()}>
                          Guardar 
                        </Button>
                      </Button.Group>
                    </Modal.Footer>
                  </Modal.Content>
                </Modal>
              </Center>
            </Center>
          </HStack>
        </VStack>

        {/* Gráfica para mostrar la actividad semanal */}
        <VStack flex={1} mt="10">
          <Heading pb="5" px="5">
            Actividad semanal
          </Heading>
          <BarChart
            barWidth={22}
            barBorderRadius={4}
            frontColor="orange"
            data={barData}
            yAxisThickness={0}
            xAxisThickness={0}
          />
        </VStack>
      </VStack>
    </ScrollView>
  );
}
