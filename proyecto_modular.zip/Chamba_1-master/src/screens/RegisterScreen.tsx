//Importacion de componentes
import { Keyboard, Alert } from "react-native";
//Importar componentes de native base
import { VStack,
  Image, 
  Heading, 
  Text, 
  FormControl, 
  Stack, 
  Input, 
  Button, 
  Box, 
  Link, 
  Flex } from 'native-base';
import { useForm } from '../hooks/useForm';
import { useContext, useEffect,useState } from "react";
import { AuthContext } from "../context/AuthContext";
import { StackScreenProps } from "@react-navigation/stack";

// Components 
import MastheadLogin from "../components/masthead-login";
import { LoadingScreen } from "./LoadingScreen";

interface Props extends StackScreenProps<any,any> {}

/*En esa función se agregan todos los componentes de la vista del registro */
export default function RegisterScreen({navigation}:Props) {

  const { signUp, errorMessage, removeError } = useContext( AuthContext );

  const {name, email, password, onChange} = useForm({
    name:'',
    email:'',
    password: ''
  });
  const [loading, setLoading] = useState<Boolean>(false);

  useEffect (() => {
    if(errorMessage.length === 0) return;

    Alert.alert('Registro incorrecto', errorMessage,[{
          text: 'ok',
          onPress: removeError
        }]
        );
  }, [errorMessage])

  const onRegister = () => {
    console.log({name, email, password});
    try {
    setLoading(true);
    Keyboard.dismiss();
    signUp({
      nombre: name,
      correo: email,
      password
    });
    }catch(error){
      console.log(error);
    }finally{
      setLoading(false);
    }
  }

  if(loading) return <LoadingScreen />

    return (

      /* Contenedor de toda la vista */
    <VStack flex={1} bg="white">
      {/*imagen con el logo*/}
      <MastheadLogin />  
        {/*Frase de bienvenida */}   
        <VStack mt="170px" px="9" w="full" h="20">
            <Heading fontSize="4xl">¡Hola!</Heading>
            <Text fontSize="md">Crea una cuenta nueva</Text>
        </VStack>
        <VStack px="5" flex={1} space={7}>
        <FormControl>
          {/*Inputs para crear una cuenta nueva*/}  
          <Stack mx="4">
            <Input size="md" type="text" variant="underlined" placeholder="Nombre de usuario"

            /*Obtener nombre de usuario*/
            onChangeText={ (value) => onChange(value, 'name') }
            value={name}
            onSubmitEditing={ onRegister }

            />
          </Stack>
        </FormControl>
        <FormControl>
          <Stack mx="4">
            <Input size="md" type="text" variant="underlined" placeholder="Correo"

            /*Obtener email*/
            onChangeText={ (value) => onChange(value, 'email') }
            value={email}
            onSubmitEditing={ onRegister }

            />
          </Stack>
        </FormControl>
        <FormControl>
          <Stack mx="4">
            <Input size="md" type="password" variant="underlined" placeholder="Contraseña" 
            
            /*Obtener contraseña*/
            onChangeText={ (value) => onChange(value, 'password') }
            value={password}
            onSubmitEditing={ onRegister }

            />
            <FormControl.HelperText>
              Debes introducer al menos 6 caracteres.
            </FormControl.HelperText>
          </Stack>
        </FormControl>
        <Box mt="9" alignItems="center" >
          {/*Botón para registrar al usuario*/}  
      <Button size="md" w="60%" h="48px" bg="light.900" onPress={onRegister} >Registrarse</Button>
    </Box>
    <VStack>
            <Flex direction="row" justifyContent="center"> 
            <Text>¿Ya tienes una cuenta? </Text>
            <Box alignItems="center">
              {/*Link para que el usuario pueda regresar a la pantalla de login*/} 
      <Link href="" onPress={()=>{navigation.replace("Login")}} _text={{color:"warning.400"}}>
        Ingresa aquí
      </Link>    
    </Box>
    </Flex>
        </VStack>
        </VStack>
    </VStack>
    )
  }
