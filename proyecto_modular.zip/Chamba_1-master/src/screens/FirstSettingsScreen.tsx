import { useContext } from "react";
import {
  Heading,
  Center,
  VStack,
  Text,
  Button,
  Select,
  CheckIcon
} from "native-base";
import {useWindowDimensions, } from 'react-native';
import { useForm } from "../hooks/useForm";
import { RegisterContext } from "../context/RegistersContext";
import { StackScreenProps } from '@react-navigation/stack';

interface Props extends StackScreenProps<any, any> {}


export default function FirstSettingsScreen({navigation}: Props){

  // Obtener la dimension width
  const {width} = useWindowDimensions();

  // Context Register 
  const {saveRegister} = useContext(RegisterContext);


  const {numeroRodado, onChange, clearForm} = useForm({
    numeroRodado: '',
  });
  

  const handleSaveRodado = async () => {
    if (numeroRodado.length == 0) return;
    await saveRegister(numeroRodado);
    clearForm();
    navigation.replace('MainScreen');
    
  };
  
  return (
    <VStack flex={1} flexDirection="column" justifyContent="space-between" p="10">
      <VStack bg="gray.100" >
          <Center><Heading fontSize="3xl">Configuración inicial</Heading></Center>
          <Center><Text fontSize="lg" style={{
            textAlign: 'center',
            marginTop: 20
          }}>Ingresa el número de rueda de la bicicleta para poder continuar</Text></Center>
          <VStack w="full" mt="5">
            <Select
                    selectedValue={numeroRodado}
                    minWidth= {width * 0.7}
                    accessibilityLabel="Elegir el rodado de tu bicicleta"
                    placeholder="Elegir el rodado de tu bicicleta"
                    _selectedItem={{
                      bg: 'warning.400',
                      endIcon: <CheckIcon size="5" />,
                    }}

                    _text={{
                      color: 'gray.900',
                      fontSize: 'lg'
                    }}

                    mt={1}
                    onValueChange={itemValue =>
                      onChange(itemValue, 'numeroRodado')
                    }>
                    <Select.Item label="26'" value="26" />
                    <Select.Item label="27.5'" value="27.5" />
                    <Select.Item label="29" value="29" />
                  </Select>

          </VStack>
      </VStack>
      <VStack w="full">
        <Center>
          <Button size="sm" bg="warning.500" _text={{ color: "gray.50", fontSize: 'lg'}} _pressed={{bg : 'warning.400'}} variant="outline" py="3" px="20" onPress={() => handleSaveRodado()}>Continuar</Button>
        </Center>
      </VStack>

    </VStack>
  )
}
