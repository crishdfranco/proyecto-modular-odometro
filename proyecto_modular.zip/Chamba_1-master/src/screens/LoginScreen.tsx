import {useState} from 'react';
//Importacion de componentes
import { Keyboard, Alert} from 'react-native';
//Importar componentes de native base
import {
  VStack,
  Image,
  Heading,
  Text,
  FormControl,
  Stack,
  Input,
  Button,
  Box,
  Link,
  Flex,
} from 'native-base';
import { useForm } from '../hooks/useForm';
import { useContext, useEffect } from 'react';
import { AuthContext } from '../context/AuthContext';
import { StackScreenProps } from '@react-navigation/stack';

import MastheadLogin from '../components/masthead-login'; 
import { LoadingScreen } from './LoadingScreen';

interface Props extends StackScreenProps<any, any> {}

/*En esa función se agregan todos los componentes de la vista del login*/
export default function LoginScreen({navigation}: Props) {

  const { signIn, errorMessage, removeError } = useContext( AuthContext );
  
  const {email, password, onChange} = useForm({
    email:'',
    password: ''
  });
  
  const [loading, setLoading] = useState<Boolean>(false);

  useEffect(() => {
    if(errorMessage.length === 0) return;

    Alert.alert('Inicio de sesión incorrecto', errorMessage,[{
          text: 'ok',
          onPress: removeError
        }]
        );
  }, [errorMessage])

  const onLogin = () => {
    setLoading(true);
    Keyboard.dismiss();

    signIn({ correo: email, password });
    setLoading(false);

  }

  if(loading) return <LoadingScreen />
  
  return (

    /* Contenedor de toda la vista */
    <VStack flex={1} bg="white">
      {/*imagen con el logo*/}
      < MastheadLogin/>

      {/*Frase de bienvenida */}
      <VStack mt="170px" px="9" w="full" h="20">
        <Heading fontSize="4xl">Bienvenido</Heading>
        <Text fontSize="md">Inicia sesión para continuar</Text>
      </VStack>
      {/*Inputs para crear una cuenta nueva*/}
      <VStack px="5" flex={1} space={7}>
        <FormControl>
          <Stack mx="4">
            <Input
              size="md"
              type="text"
              variant="underlined"
              placeholder="Correo"

              /*Obtener email*/
              onChangeText={ (value) => onChange(value, 'email') }
              value={email}
              onSubmitEditing={ onLogin }

            />
          </Stack>
        </FormControl>
        <FormControl>
          <Stack mx="4">
            <Input
              size="md"
              type="password"
              variant="underlined"
              placeholder="Contraseña"
              secureTextEntry

              /*Obtener contraseña*/
              onChangeText={ (value) => onChange(value, 'password') }
              value={password}
              onSubmitEditing={ onLogin }

            />
            <FormControl.HelperText></FormControl.HelperText>
          </Stack>
        </FormControl>
        <Box mt="9" alignItems="center">
          {/*Botón para que el usuario inicie sesión*/}
          <Button
            size="md"
            w="60%"
            h="48px"
            bg="light.900"
            onPress={onLogin}
            >
            Ingresar
          </Button>
        </Box>
        <VStack>
          <Flex mt="20%" direction="row" justifyContent="center">
            <Text>¿No tienes una cuenta? </Text>
            <Box alignItems="center">
              {/*Link para que el usuario pueda registrarse si no tiene una cuenta*/}
              <Link
                href=""
                onPress={() => {
                  navigation.replace('Register');
                }}
                _text={{color: 'warning.400'}}>
                Registrate
              </Link>
            </Box>
          </Flex>
        </VStack>
      </VStack>
    </VStack>
   // </KeyboardAvoidingView>
  );
}
