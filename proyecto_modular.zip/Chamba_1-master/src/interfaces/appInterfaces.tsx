export interface LoginData {
    correo:   string;
    password: string;
}

export interface RegisterData {
    nombre:   string;
    correo:   string;
    password: string;
}

export interface LoginResponse {
    usuario: Usuario;
    token: string;
}

export interface Usuario {
    nombre: string;
    correo: string;
    uid: string;
}



// Registers 
export interface manageRegisterResponse{
    registro : string;
}

export interface Registro{
    nRueda: string;
}

export interface nRueda{
    nRueda: string;
}

