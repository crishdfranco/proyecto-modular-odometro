module.exports = {
  root: true,
  rules: {
    'prettier/prettier': 0,
  },
  extends: '@react-native',
  
};
