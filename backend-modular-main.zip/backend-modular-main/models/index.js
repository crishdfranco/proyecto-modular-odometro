

const Server = require('./server');
const Usuario = require('./usuario');
const Registro = require('./registro');



module.exports = {
    Server,
    Usuario,
    Registro
}

