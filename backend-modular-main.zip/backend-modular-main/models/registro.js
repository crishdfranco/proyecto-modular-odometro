
const { Schema, model } = require('mongoose');

const RegistroSchema = Schema({
    nRueda: {
        type: String,
        required: [true, 'El numero de rueda de bicicleta es obligatorio']
    },
    // Generar una relacion al usuario
    usuario: {
        type: Schema.Types.ObjectId,
        ref: 'Usuario',
        required: true
    },
});


RegistroSchema.methods.toJSON = function() {
    const { __v, _id, ...registro  } = this.toObject();
    registro.uid = _id;
    return registro;
}


module.exports = model( 'Registro', RegistroSchema );
