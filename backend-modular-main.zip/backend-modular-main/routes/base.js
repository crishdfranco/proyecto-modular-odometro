const { Router } = require("express");

const router = Router();

router.get('/',()=>{
    res.json({
        ok:true,
        msg:'Hola Mundo'
    });
})

module.exports = router;
