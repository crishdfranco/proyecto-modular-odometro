const { Router } = require("express");
const { check } = require("express-validator");

const { validarCampos, validarJWT } = require("../middlewares");
const {
  guardarRegistro,
  obtenerRegistro,
  editarRegistro,
} = require("../controllers/registros");

const router = Router();

router.post(
  "/guardarRegistro",
  [
    check("nRueda", "El numero de rueda de la bicicleta es obligatorio")
      .not()
      .isEmpty(),
    validarCampos,
    validarJWT,
  ],
  guardarRegistro
);

// Obtener el registro del usuario
router.get("/", [validarJWT],obtenerRegistro);

// Actualizar el registro
router.put("/",[validarJWT],editarRegistro);

module.exports = router;
