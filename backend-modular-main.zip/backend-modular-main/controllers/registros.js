const { response } = require('express');

const Registro = require('../models/registro');


const guardarRegistro = async(req, res = response) => {

    const nRueda = req.body.nRueda;

    try {
      
        // Verificar si el usuario ya ha agregado el numero de rueda con el id
        // req.usuario._id
        const idUsuario = req.usuario._id;
        const registro = await Registro.findOne({ usuario : idUsuario });
        if ( registro ) {
            return res.status(204).json({
                registro : ''
            });
        }

        const data = {
            nRueda, 
            usuario : req.usuario._id
        }
        const registroNuevo = new Registro(data);
        await registroNuevo.save();
        res.status(201).json({
            registro : registroNuevo.nRueda
        })

        // res.status('201').json({
        //     msg : 'Todo bien',
        //     data,
        //     registroNuevo
        // })
        

    } catch (error) {
        console.log(error)
        res.status(500).json({
            msg: 'Hable con el administrador'
        });
    }   

}

// Obtener el registro del usuario
const obtenerRegistro = async(req, res = response) => {
    // Obtener el id del usuario 
    const usuario = req.usuario._id;

    try {
        
        // Buscar el registro con el id del usuario
        const registro = await Registro.findOne({ usuario });
        if ( !registro ) {
            return res.status(204).json({
                registro : ''
            });
        }

        
        const {nRueda} = registro;
        res.status(201).json({
            registro : nRueda
        })

    } catch (error) {
        console.log(error)
        res.status(500).json({
            msg: 'Hable con el administrador'
        });
    }   

}

// Editar el registro
const editarRegistro = async(req, res = response)=>{
    const { _id, nRueda, ...resto } = req.body;
    // console.log(req);
    const usuario = req.usuario._id;

    try {
        const registro = await Registro.findOne({usuario});
        if(!registro){
            return res.status(204).json({
                registro : ''
            });
        }
        const registroActualizado = await Registro.findByIdAndUpdate(registro.id, {nRueda},{ new: true });
        res.status(201).json({
            registro : registroActualizado.nRueda
        })
    } catch (error) {
        console.log(error)
        res.status(500).json({
            msg: 'Hable con el administrador'
        });
    }   

}




module.exports = {
    guardarRegistro,
    obtenerRegistro,
    editarRegistro
}
